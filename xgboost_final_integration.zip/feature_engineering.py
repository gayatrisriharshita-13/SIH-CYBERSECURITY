
import re
import ipaddress
from urllib.parse import urlparse


# ============================================================
# Keyword definitions
# ============================================================

SUSPICIOUS_KEYWORDS = [
    "login",
    "signin",
    "verify",
    "verification",
    "secure",
    "security",
    "account",
    "update",
    "confirm",
    "confirmation",
    "password",
    "credential",
    "wallet",
    "payment",
    "bank",
    "recover",
    "unlock",
    "suspend",
    "authorize",
    "authentication"
]

BRAND_KEYWORDS = [
    "paypal",
    "amazon",
    "apple",
    "microsoft",
    "google",
    "facebook",
    "instagram",
    "netflix",
    "linkedin",
    "twitter",
    "docusign",
    "dropbox",
    "bankofamerica",
    "wellsfargo",
    "chase",
    "citibank",
    "americanexpress",
    "visa",
    "mastercard",
    "ebay",
    "coinbase"
]


# ============================================================
# Helper
# ============================================================

def is_ip_address(host):
    """Return 1 if host is an IPv4/IPv6 address, otherwise 0."""

    if not host:
        return 0

    host = host.split(":")[0]

    try:
        ipaddress.ip_address(host)
        return 1
    except ValueError:
        return 0


# ============================================================
# Main feature extraction
# ============================================================

def extract_features(url):
    """
    Convert a URL into the 39 features expected by
    the CyberMail XGBoost phishing classifier.

    Returns:
        dict: feature name -> feature value
    """

    url = str(url).strip()

    parsed = urlparse(url)

    scheme = parsed.scheme.lower()
    domain = parsed.netloc.lower()

    # Remove username/password and port
    host = domain.split("@")[-1].split(":")[0]

    path = parsed.path or ""
    query = parsed.query or ""
    fragment = parsed.fragment or ""

    full_lower = url.lower()

    # --------------------------------------------------------
    # Basic lengths
    # --------------------------------------------------------

    url_length = len(url)
    domain_length = len(host)
    path_length = len(path)
    query_length = len(query)
    fragment_length = len(fragment)

    # --------------------------------------------------------
    # Character counts
    # --------------------------------------------------------

    num_digits = sum(c.isdigit() for c in url)
    num_letters = sum(c.isalpha() for c in url)

    num_dots = url.count(".")
    num_hyphens = url.count("-")
    num_slashes = url.count("/")
    num_question_marks = url.count("?")
    num_equals = url.count("=")
    num_ampersands = url.count("&")
    num_at_symbols = url.count("@")
    num_colons = url.count(":")
    num_underscores = url.count("_")

    # Percent encoded characters: %XX
    num_percent_encoded = len(
        re.findall(r"%[0-9a-fA-F]{2}", url)
    )

    num_semicolons = url.count(";")

    num_special_chars = len(
        re.findall(r"[^A-Za-z0-9]", url)
    )

    # --------------------------------------------------------
    # Ratios
    # --------------------------------------------------------

    digit_ratio = (
        num_digits / url_length
        if url_length else 0.0
    )

    letter_ratio = (
        num_letters / url_length
        if url_length else 0.0
    )

    special_char_ratio = (
        num_special_chars / url_length
        if url_length else 0.0
    )

    # --------------------------------------------------------
    # Domain features
    # --------------------------------------------------------

    domain_digit_count = sum(
        c.isdigit() for c in host
    )

    domain_hyphen_count = host.count("-")
    domain_dot_count = host.count(".")

    is_domain_ip = is_ip_address(host)

    domain_parts = host.split(".") if host else []

    if is_domain_ip:
        num_subdomains = 0
    elif len(domain_parts) >= 3:
        num_subdomains = len(domain_parts) - 2
    else:
        num_subdomains = 0

    has_www = int(host.startswith("www."))

    # --------------------------------------------------------
    # HTTPS
    # --------------------------------------------------------

    is_https = int(scheme == "https")

    # --------------------------------------------------------
    # Encoding / obfuscation
    # --------------------------------------------------------

    encoded_char_count = num_percent_encoded

    has_obfuscation = int(
        num_percent_encoded > 0
        or "xn--" in host.lower()
    )

    # --------------------------------------------------------
    # Path
    # --------------------------------------------------------

    path_slashes = path.count("/")

    path_segments = [
        segment
        for segment in path.split("/")
        if segment
    ]

    num_path_segments = len(path_segments)

    # --------------------------------------------------------
    # Suspicious keywords
    # --------------------------------------------------------

    suspicious_keyword_count = sum(
        1
        for keyword in SUSPICIOUS_KEYWORDS
        if keyword in full_lower
    )

    has_suspicious_keyword = int(
        suspicious_keyword_count > 0
    )

    # --------------------------------------------------------
    # Brand keywords
    # --------------------------------------------------------

    brand_keyword_count = sum(
        1
        for brand in BRAND_KEYWORDS
        if brand in full_lower
    )

    has_brand_keyword = int(
        brand_keyword_count > 0
    )

    # Brand specifically in path/query
    path_query_lower = (
        path + "?" + query
    ).lower()

    brand_in_path_or_query = int(
        any(
            brand in path_query_lower
            for brand in BRAND_KEYWORDS
        )
    )

    # --------------------------------------------------------
    # Query parameters
    # --------------------------------------------------------

    if query:
        query_parameter_count = len(
            [
                item
                for item in query.split("&")
                if item
            ]
        )
    else:
        query_parameter_count = 0

    # ========================================================
    # EXACT 39-FEATURE OUTPUT
    # ========================================================

    return {
        "URLLength": url_length,
        "DomainLength": domain_length,
        "PathLength": path_length,
        "QueryLength": query_length,
        "FragmentLength": fragment_length,
        "NumDigits": num_digits,
        "NumLetters": num_letters,
        "NumDots": num_dots,
        "NumHyphens": num_hyphens,
        "NumSlashes": num_slashes,
        "NumQuestionMarks": num_question_marks,
        "NumEquals": num_equals,
        "NumAmpersands": num_ampersands,
        "NumAtSymbols": num_at_symbols,
        "NumColons": num_colons,
        "NumUnderscores": num_underscores,
        "NumPercentEncoded": num_percent_encoded,
        "NumSemicolons": num_semicolons,
        "NumSpecialChars": num_special_chars,
        "DigitRatio": digit_ratio,
        "LetterRatio": letter_ratio,

        # IMPORTANT:
        # Exact spelling expected by final XGBoost model.
        "SpecialCharRatio": special_char_ratio,

        "DomainDigitCount": domain_digit_count,
        "DomainHyphenCount": domain_hyphen_count,
        "DomainDotCount": domain_dot_count,
        "IsDomainIP": is_domain_ip,
        "NumSubdomains": num_subdomains,
        "HasWWW": has_www,
        "IsHTTPS": is_https,
        "EncodedCharCount": encoded_char_count,
        "HasObfuscation": has_obfuscation,
        "PathSlashes": path_slashes,
        "NumPathSegments": num_path_segments,
        "SuspiciousKeywordCount": suspicious_keyword_count,
        "HasSuspiciousKeyword": has_suspicious_keyword,
        "BrandKeywordCount": brand_keyword_count,
        "HasBrandKeyword": has_brand_keyword,
        "BrandInPathOrQuery": brand_in_path_or_query,
        "QueryParameterCount": query_parameter_count
    }
