# CyberMail XGBoost URL Phishing Classifier

Integration-ready XGBoost model for URL phishing detection.

## Classification

0 = Safe
1 = Phishing

## Model

Model: XGBoost Classifier
Features: 39

## Performance

Validation Accuracy: 94.75%
Validation F1: 94.76%
Validation ROC-AUC: 99.01%

Test Accuracy: 94.49%
Test F1: 94.54%
Test ROC-AUC: 98.95%

Zero-Day Accuracy: 94.98%
Zero-Day F1: 95.02%
Zero-Day ROC-AUC: 99.06%

## Files

xgboost_final.json
    Trained XGBoost model.

feature_schema.json
    Exact 39-feature schema expected by the model.

feature_engineering.py
    Converts a URL into the 39 model features.

predictor.py
    Main integration interface.

## Usage

from predictor import predict_url

result = predict_url("https://example.com")

The result contains:

prediction
label
phishing_probability
safe_probability

## Integration Flow

URL
  |
  v
feature_engineering.py
  |
  v
39 Features
  |
  v
xgboost_final.json
  |
  v
Safe / Phishing
  |
  v
Probability

## FastAPI Integration

The backend can use:

from predictor import predict_url

result = predict_url(url)

The returned result can then be sent to the frontend
or passed to the Risk Score Engine.

## Important

Do not change the feature names or feature order.

The official feature schema is stored in feature_schema.json.

This package has been tested with the final XGBoost
model and the standalone prediction interface.