from predictor import predict_url

TEST_URLS = [
    "https://www.google.com",
    "https://www.amazon.com/account/login",
    "http://paypal-security-verify.com/login?account=12345",
    "http://192.168.1.100/login/verify.php?user=test",
    "https://example.com/products/item?id=123"
]

for url in TEST_URLS:

    result = predict_url(url)

    print("=" * 60)
    print("URL:", url)
    print("Prediction:", result["label"])
    print(
        "Phishing probability:",
        round(result["phishing_probability"], 4)
    )
    print(
        "Safe probability:",
        round(result["safe_probability"], 4)
    )

print()
print("Model package test completed successfully.")