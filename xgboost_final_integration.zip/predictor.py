
import os
import json
import pandas as pd
import xgboost as xgb

from feature_engineering import extract_features


# ============================================================
# Paths
# ============================================================

BASE_DIR = os.path.dirname(
    os.path.abspath(__file__)
)

MODEL_PATH = os.path.join(
    BASE_DIR,
    "xgboost_final.json"
)

SCHEMA_PATH = os.path.join(
    BASE_DIR,
    "feature_schema.json"
)


# ============================================================
# Load model
# ============================================================

model = xgb.XGBClassifier()

model.load_model(MODEL_PATH)


# ============================================================
# Load feature schema
# ============================================================

with open(SCHEMA_PATH, "r") as f:
    schema = json.load(f)

MODEL_FEATURES = schema["features"]


# ============================================================
# Safety checks
# ============================================================

if len(MODEL_FEATURES) != 39:
    raise ValueError(
        f"Expected 39 features, "
        f"found {len(MODEL_FEATURES)}"
    )

MODEL_ACTUAL_FEATURES = (
    model.get_booster().feature_names
)

if MODEL_FEATURES != MODEL_ACTUAL_FEATURES:
    raise ValueError(
        "Feature schema does not match "
        "the trained XGBoost model."
    )


# ============================================================
# Prediction function
# ============================================================

def predict_url(url):
    """
    Predict whether a URL is safe or phishing.

    Args:
        url (str): URL to classify.

    Returns:
        dict containing:
            prediction
            label
            phishing_probability
            safe_probability
    """

    if not isinstance(url, str):
        raise TypeError(
            "URL must be a string."
        )

    if not url.strip():
        raise ValueError(
            "URL cannot be empty."
        )

    # Extract features
    features = extract_features(url)

    # Create DataFrame in EXACT model order
    X = pd.DataFrame(
        [[features[name] for name in MODEL_FEATURES]],
        columns=MODEL_FEATURES
    )

    # Prediction
    prediction = int(
        model.predict(X)[0]
    )

    probabilities = model.predict_proba(X)[0]

    safe_probability = float(
        probabilities[0]
    )

    phishing_probability = float(
        probabilities[1]
    )

    return {
        "prediction": prediction,
        "label": (
            "Phishing"
            if prediction == 1
            else "Safe"
        ),
        "phishing_probability":
            phishing_probability,
        "safe_probability":
            safe_probability
    }
